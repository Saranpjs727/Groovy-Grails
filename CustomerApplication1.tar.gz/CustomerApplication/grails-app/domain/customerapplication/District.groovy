package customerapplication

class District {

    static constraints = {
        district  nullable: false,blank: false
    }
    static belongsTo=[state:State]
    static hasMany=[address:Address]
    String district
}
