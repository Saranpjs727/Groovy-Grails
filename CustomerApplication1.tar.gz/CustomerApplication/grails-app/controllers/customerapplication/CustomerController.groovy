package customerapplication

class CustomerController {

    def create(){
        def addressList=Address.list()
        render(view:"create",model:[addressList:addressList])
    }
    def operation()
    {
    }
    def save() { 
        def doorNo=params.doorNo
        def addressIns=Address.get(doorNo)
        def customerIns=new Customer()
        customerIns.userName=params.userName
        customerIns.dateOfBirth=params.dateOfBirth
        customerIns.email=params.email
        customerIns.address=addressIns
        customerIns.password=params.password
        if(customerIns.validate()){
            customerIns.save(flush:true,failOnError:true)
            render view:"operation"
        }
        else{
            flash.message="Please check all the fields"
            def addressList=Address.list()
            render(view:"create",model:[addressList:addressList])
        }
    }
    def display()
    {
        def customerList=Customer.list()
        [temp:customerList]
    }
    def delete()
    {
        def customerList=Customer.list()
        render(view:"delete",model:[customerList:customerList])
    }
    def deleteAction()
    {
        def email=params.email
        def customerInst=Customer.get(email)
        customerInst.delete(flush:true)
        render view:"operation"
    }
    def update()
    {
        def customerList=Customer.list()
        render(view:"update",model:[customerList:customerList])
    }
    def updateAction()
    {
        def oldName=params.oldName
        def id=Integer.parseInt(oldName)
        // def id1=Customer.get(id)
        def newNameIns=params.newName
        Customer.executeUpdate("update Customer cs set cs.userName='"+newNameIns+"' where cs.id='"+id+"'")
        render view:"operation"
    }
}
