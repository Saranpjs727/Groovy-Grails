package customerapplication

class StateController {

    def create(){
        def countryList=Country.list()
        render(view:"create",model:[countryList:countryList])
    }
    def operation()
    {
    }
    def save() { 
       def stateName=params.state
       def countryId=params.countryList
       def id=Integer.parseInt(countryId)
       def countryIns=Country.get(id)
       def stateIns=new State()
       stateIns.state=stateName
       stateIns.country=countryIns
       if(stateIns.validate()){
            stateIns.save(flush:true,failOnError:true)
            render view:"operation"
        }
      else{
            flash.message="Please check all the fields"
           def countryList=Country.list()
          render(view:"create",model:[countryList:countryList])
        }
   }
   def display()
   {
        def stateList=State.list()
        [temp:stateList]
   }
   def delete()
   {
        def stateList=State.list()
        render(view:"delete",model:[stateList:stateList])
   }
   def deleteAction()
    {
        def state=params.state
        def stateInst=State.get(state)
        stateInst.delete(flush:true)
        render view:"operation"
    }
    def update()
    {
         def stateList=State.list()
         render(view:"update",model:[stateList:stateList])
    }
    def updateAction()
    {
        def id1=params.oldState
        def id=Integer.parseInt(id1)
        def stateOld=State.get(id)
        def stateNew=params.newState
        State.executeUpdate("update State s set s.state='"+stateNew+"' where s.id='"+id+"'")
        render view:"operation"
     }
}